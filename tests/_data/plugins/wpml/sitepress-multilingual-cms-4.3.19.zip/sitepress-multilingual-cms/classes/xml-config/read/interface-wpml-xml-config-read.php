<?php
/**
 * @author OnTheGo Systems
 */
interface WPML_XML_Config_Read {

}