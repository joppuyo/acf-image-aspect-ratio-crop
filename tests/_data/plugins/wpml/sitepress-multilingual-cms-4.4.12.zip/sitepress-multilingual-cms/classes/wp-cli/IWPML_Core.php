<?php
namespace WPML\CLI\Core\Commands;

interface IWPML_Core extends IWPML_Command_Factory {
}